######
# Functions for analyzing self-paced reading data in R
# by Klinton Bicknell and Roger Levy
# Provides (user-available functions):
#
# note: functions assume that factors are discrete, not continuous
#
# analyze.spr(dat, factors, region.list, use.res = F,
#             res.correct = T, analyze.correct = T, lower=100,
#             upper=5000, subj.name = 'subj', item.name = 'item',
#             correct.name = 'correct', filler.name='filler',
#             region.name = 'region', rt.name = 'rt', wordlen.name =
#             'wordlen', outlier.factors=c(), outlier.method = 'sd',
#             outlier.multiplier=3, outlier.replace=F)
# analyze.errors(dat, factors=c(), subj.name = 'subj',
#                item.name = 'item', correct.name = 'correct')
# res.rt(dat, subj.name='subj', wordlen.name='wordlen', rt.name='rt')
#     RETURNS res.rt
# find.outliers(dat, factors, region.list, method='iq',
#       multiplier=1.5, rt.name='rt', region.name='region') RETURNS to.remove
# analyze.rts(dat, factors, region.list, subj.name = 'subj', 
#             item.name='item', rt.name='rt', region.name='region')
# first.cut(dat, rt.name='rt', lower=100, upper=5000) RETURNS to.remove
######

## utility functionlets
rounded.mean <- function(x) round(mean(x), 2)
rounded.se <- function(x) round(se(x), 2)


## macro function

analyze.spr <- function(dat, factors, region.list, use.res = F,
            analyze.correct = F, res.correct = analyze.correct,
            lower=100, upper=5000, subj.name = 'subj', item.name =
            'item', correct.name = 'correct', filler.name='filler',
            region.name = 'region', rt.name = 'rt', wordlen.name =
            'wordlen', outlier.factors=c(), outlier.method = 'sd',
            outlier.multiplier=3, outlier.replace=F, f.sigdigits=2,
            p.sigdigits=3, do.plot=TRUE, plot.type="line",
            do.first.cut=TRUE, ylab=NULL,
            do.anovas=TRUE,table.writer=function(x) print(x),
            arcsine.transform.qa=FALSE,...) { if (is.null(ylab)) { if
            (use.res==T) ylab='Residual reading time (ms)' else
            ylab='Reading time (ms)' }
  
  ## overall accuracy analysis
  if(! is.factor(dat[[subj.name]]))
    stop("Error: subj is not a factor.  Quitting analyze.spr()...")
    if(! is.factor(dat[[item.name]]))
    stop("Error: item is not a factor.  Quitting analyze.spr()...")
  cat("### Overall accuracy analysis ###\n")

  analyze.errors(dat, c(), subj.name, item.name, correct.name,arcsine.transform=arcsine.transform.qa)

  if (res.correct == T & analyze.correct == F) {

    cat('\n Warning: Inconsistent values of res.correct and analyze.correct.',
		'Setting analyze.correct to be True.\n')
    analyze.correct = T
  }
  dat[[correct.name]] = (dat[[correct.name]] == 1 | dat[[correct.name]] == T)  
  # accuracy analysis for experimental items
  if(! is.null(filler.name))
    dat.exp <- dat[!dat[[filler.name]],]
  else
    dat.exp <- dat
  
  if (nrow(subset(dat.exp, !is.na(correct.name)))>0) { # if any experimental items have questions
    cat("### Condition-specific accuracy analysis ###\n")
    qa.results<- analyze.errors(dat.exp, factors, subj.name, item.name, correct.name,arcsine.transform=arcsine.transform.qa)
  }
                                              
  # now analyze RTs
  
  if(do.first.cut) {
    cat("### Seeking first-cut outliers (RTs above ", upper, " or below ", lower, ") ###\n", sep='')
    to.remove <- first.cut(dat, rt.name, lower, upper, factors=factors)
    dat <- dat[!(to.remove), ]
  }

  if (use.res) {
    if (res.correct) {
    	cat("### Removing incorrectly answered trials prior to calculating residual RTs ###\n")
      dat <- dat[dat[[correct.name]],]
    }
    dat$res.rt <- res.rt(dat, subj.name, wordlen.name, rt.name)
    rt.name = 'res.rt'
  }

  if(! is.null(filler.name))
    dat <- dat[!dat[[filler.name]],]
    
  if (analyze.correct) {
  	cat("### Removing incorrectly answered trials ###\n")
    dat <- dat[dat[[correct.name]],]
  }
  else
    cat("### Analyzing all trials, not just correctly-answered ones ###\n")
    
  cat("### Seeking outliers...###\n")
  to.remove <- find.outliers(dat, outlier.factors, region.name, region.list,
                             outlier.method, outlier.multiplier,
                             rt.name,  replace=outlier.replace)
  if (outlier.replace) {
	cat("### Replacing outliers...###\n")
	dat[[rt.name]] <- to.remove
  } else {
  	cat("### Removing outliers...###\n")
	dat <- dat[!(to.remove),]
  }

  ## At this point: ##############
  ## 1. fillers have been removed from dat
  ## 2. incorrect questions have been removed from dat, if analyze.correct=T
  ## 3. first-cut outliers have been removed by first.cut()
  ## 4. residual RTs have been calculated, if use.res=T
  ## 5. outliers have been detected and removed/replaced
  cat("### Reading-time analysis ###\n")
  result <- analyze.rts(dat, factors, region.list, subj.name, item.name, rt.name,
		      region.name, do.plot=do.plot, plot.type=plot.type,ylab=ylab, f.sigdigits=f.sigdigits, p.sigdigits=p.sigdigits, do.anovas=do.anovas,...)
  result[["data"]] <- dat
  if (nrow(subset(dat.exp, !is.na(correct.name)))>0) { # if any experimental items have questions
    result[["qa"]] <- qa.results
  }
  invisible(result)
}

# internal function used with aggregate to ensure that there is only 1 accuracy
# score per participant per item
acc.fn <- function(x) {
  x <- subset(x, !is.na(x))
    x[1] -> correctness
    if (length(x) > 1) {
        for (i in 2:length(x)) {
            if (x[i] != correctness) {
                warning(paste("Item number",i,"item has multiple values of Correct"))
            }
        }
    }
    return(correctness)
}

# internal function to get standard errors
se <- function(x,na.rm=F) {
    if(na.rm) x <- subset(x,! is.na(x))
    sqrt(var(x)/length(x))
}

# creates list of fully factorial conditions for use in Anova, etc.
create.factorial <- function(condition.list) {
    test.list <- c()
    for(i in 1:length(condition.list)) {
        previous.length <- length(test.list)
        test.list <- c(test.list, condition.list[i])
        if (previous.length > 0) {
            for (j in 1:previous.length) {
                test.list <- c(test.list, paste(test.list[j], ':',
                                                condition.list[i], sep=''))
            }
        }
    }
    return(test.list)
}
        
# internal function - automates 'by' list creation for aggregation
make.by.text <- function(cond, dat='dat') {
    by.text <- 'list('
    for (i in 1:length(cond)) {
        by.text <- paste(by.text, sprintf('%s = %s$%s', cond[i], dat, cond[i]))
        if (i < length(cond)) {
            by.text <- paste(by.text, ',', sep='')
        }
        else {
            by.text <- paste(by.text, ')', sep='')
        }
    }
    return(by.text)
}

# used to transform a logical vector (T/F) into 1s and 0s
bool.to.int <- function(x) {
    output <- c()
    for (i in 1:length(x)) {
        if (x[i]==T) {
            output[i] <- 1
        }
        if (x[i]==F) {
            output[i] <- 0
        }
    }
    return(output)
}

# uses bool.to.int to find the proportion of TRUEs in a vector x
prop.bool <- function(x) {
    return(mean(bool.to.int(x)))
}

# do anova on errors; assumes conditions are discrete
analyze.errors <- function(dat, factors=c(), subj.name = 'subj', 
                           item.name = 'item', correct.name = 'correct',arcsine.transform=FALSE) {

  if(length(factors) == 0) {
        dat <- data.frame(subj = dat[[subj.name]], item = dat[[item.name]],
                          correct = dat[[correct.name]])
    }
    else {
        factors <- subset(dat, select=factors)
        dat <- data.frame(subj = dat[[subj.name]], item = dat[[item.name]],
                          correct = dat[[correct.name]], factors)
    }                      
    
    # make function work for correct coded as 1/0 or T/F
    dat$correct <- (dat$correct == 1 | dat$correct == T)
    
    # aggregate to have just one correct value per participant and item
    by.text <- make.by.text(c('subj', 'item', names(factors)))
    by.list <- eval(parse(text=by.text))
    dat <- aggregate(list(correct = dat$correct), by.list, acc.fn)
  dat <- subset(dat, !is.na(correct))
    
    # make the 'by' list for f1 and f2 aggregation
    by.text.f1 <- make.by.text(c('subj', names(factors)))
    by.text.f2 <- make.by.text(c('item', names(factors)))
    by.list.f1 <- eval(parse(text=by.text.f1))
    by.list.f2 <- eval(parse(text=by.text.f2))

    # aggregate dat for f1 and f2
    dat.f1 <- aggregate(list(correct = dat$correct), by.list.f1, mean)
    dat.f2 <- aggregate(list(correct = dat$correct), by.list.f2, mean)
  
    ## print means and SEs
    dat.subj <- aggregate(list(correct = dat$correct), list(subj = dat$'subj'), mean)
    dat.item <- aggregate(list(correct = dat$correct), list(item = dat$'item'), mean)
    subj.mean <- mean(dat.subj$correct)*100
    subj.se <- se(dat.subj$correct)*100
    cat(sprintf('Mean accuracy (and SE) by Subject: %.2f%% (%.2f)\n', 
                subj.mean, subj.se))
    item.mean <- mean(dat.item$correct)*100
    item.se <- se(dat.item$correct)*100
    cat(sprintf('Mean accuracy (and SE) by Item: %.2f%% (%.2f)\n', 
                item.mean, item.se))
    
    # print lowest participants and items
    num.low.subj <- 5
    if (length(dat.subj[,1]) < 5) {
      num.low.subj <- length(dat.subj[1,])
    }
    num.low.item <- 5
    if (length(dat.item[,1]) < 5) {
      num.low.item <- length(dat.item[1,])
    }
    o.subj <- order(dat.subj$correct)
    o.item <- order(dat.item$correct)
    cat('\nLowest participants:\n')
    print(dat.subj[o.subj,][1:num.low.subj,])
    cat('\nLowest items:\n')
    print(dat.item[o.item,][1:num.low.item,])

    aov.result <- list(QA=list())
    if (length(factors) > 0) {
        # print means/SEs by subj
        by.text <- make.by.text(names(factors), dat='dat.f1')
        by.list <- eval(parse(text=by.text))
        cat('\nMean accuracy by condition (by subject):\n')
        print(tapply(dat.f1$correct, by.list, rounded.mean))
        cat('\nAccuracy standard error by condition (by subject):\n')
        print(tapply(dat.f1$correct, by.list, rounded.se))
    
        # print means/SEs by item
        by.text <- make.by.text(names(factors), dat='dat.f2')
        by.list <- eval(parse(text=by.text))
        cat('\nMean accuracy by condition (by item):\n')
        print(tapply(dat.f2$correct, by.list, rounded.mean))
        cat('\nAccuracy standard error by condition (by item):\n')
        print(tapply(dat.f2$correct, by.list, rounded.se))

        response <- 'correct'
        if(arcsine.transform) {
          ## get arcsin-transformed data
          dat.f1$correct.asin <- asin(sqrt(dat.f1$correct))*180/pi
          dat.f2$correct.asin <- asin(sqrt(dat.f2$correct))*180/pi
          response <- 'correct.asin'
        }
        # create anovas
        f1.formula <- build.formula(response, names(factors), 
                                    'subj')
        f2.formula <- build.formula(response, names(factors),
                                    'item')
        f1.aov <- aov(as.formula(f1.formula), data=dat.f1)
        f2.aov <- aov(as.formula(f2.formula), data=dat.f2)
        ##cat("Formulas:\n")
        ##print(f1.formula)
        ##print(f2.formula)
        
        # create a list of the fully crossed conditions to test
        test.list <- create.factorial(names(factors))
        
        # print results of anova cat('\nAccuracy ANOVA Results\n')
        for(i in 1:length(test.list)) {
          aov.result[["QA"]][[test.list[i]]] <-
            print.anova.f1.f2(test.list[i], f1.aov, f2.aov, 'subj', 'item')
        }
      }

  result <- list(f1=dat.f1,f2=dat.f2,aov=aov.result)
  invisible(result)
}

# create a column of residual RTs by participant
res.rt <- function(dat, subj.name='subj', wordlen.name='wordlen',
                        rt.name='rt', verbose=T) {
  if(! is.element(wordlen.name,names(dat)))
    stop(paste("Error: your data frame doesn't contain a compoment for wordlength named",wordlen.name))
    dat <- data.frame(subj = dat[[subj.name]], wordlen = dat[[wordlen.name]],
                      rt = dat[[rt.name]])
    length.slope <- c() # just to see what typical slope is
    res.rt <- c() # full list of residual rts

    for(i in levels(dat$subj)) {
      wordlen.subj <- dat$wordlen[dat$subj==i]
      if(length(wordlen.subj) == 0)
        next
      rt.subj <- dat$rt[dat$subj==i]
      model <- lm(rt.subj~wordlen.subj)
      res.rt[dat$subj==i] <- residuals(model)
      length.slope <- c(length.slope, model$coef["wordlen.subj"])
    }
    mean.slope <- mean(length.slope)
    se.slope <- se(length.slope)
    if (verbose) {
      cat(sprintf('The mean slope was %.1f with an se of %.1f.\n',
                  mean.slope, se.slope))
    }
    return(res.rt)
}

# plots rts/res.rts with error bars
plot.rts <- function(dat, rt.name='rt', region.name='region',
                     cond.name='joint.cond', plot.type='line',lty.function=NULL, 
					 pch.function=NULL, col.function=NULL, bg.function=NULL,
					 lty=1:6, col=1:8, pch=1:8, bg=col,
					 ylab='Reading time (ms)', ylim=NULL,main=NULL,...) {
    dat <- data.frame(region = dat[[region.name]], cond = dat[[cond.name]],
                      rt = dat[[rt.name]])
    ## find appropriate range for graph with errors bars
    # reg <- levels(dat$region)[1]
    # con <- levels(dat$cond)[1]
    # con.dat <- subset(dat, region==reg & cond==con)
    # graph.min <- graph.max <- mean(con.dat$rt)
    
    grand.mean <- with(dat,mean(tapply(rt, list(region, cond),mean,na.rm=T),na.rm=T))
    graph.min <- graph.max <- grand.mean    
    
    for (reg in levels(dat$region)){
        for (con in levels(dat$cond)) {
            con.dat <- subset(dat, region==reg & cond==con)
            # only if this pair of condition and region has data
            if (length(con.dat[,1]) > 0) {
              word.mean <- mean(con.dat$rt)
              word.se <- se(con.dat$rt, na.rm=T)
              yplus<-word.mean+word.se
              yminus<-word.mean-word.se
              if(yplus>graph.max){graph.max <- yplus}
              if(yminus<graph.min){graph.min <- yminus}
            }
         }
    }
    ##cat("### levels are",class(levels(dat$cond)), ":\n")
    
    print(levels(dat$cond))

    if(! is.null(lty.function)) {
      lty <- sapply(levels(dat$cond), lty.function)
      cat("### Assigning special lty...\n")
    }
    if(! is.null(col.function)) {
      col <- sapply(levels(dat$cond), col.function)
      cat("### Assigning special col...\n")
    }
    if(! is.null(pch.function)) {
      pch <- sapply(levels(dat$cond), pch.function)
      cat("### Assigning special pch...\n")
    }
    if(! is.null(bg.function)) {
      bg <- sapply(levels(dat$cond), bg.function)
      cat("### Assigning special bg...\n")
    }

    if(is.null(ylim))
      ylim <- c(graph.min - 10, graph.max + 10)
    
    # Plot graph
    if(plot.type=="line") {
      with(dat, interaction.plot(region,cond, rt, type='b',
                                 ylim=ylim, xlab=NA,
                                 col=col, lty=lty, pch=pch, bg=bg,leg.bg=bg,bty='n',
                                 ylab=ylab, ...))

      ## plot error bars
      i <- 1 # x value of current word
      for (reg in levels(dat$region)){
        for (con in levels(dat$cond)) {
          con.dat <- subset(dat, region==reg & cond==con)
          ## only if this pair of condition and region has data
          if (length(con.dat[,1]) > 0) {          
            word.mean <- mean(con.dat$rt)
            word.se <- se(con.dat$rt, na.rm=T)
            yplus<-word.mean+word.se
            yminus<-word.mean-word.se
            arrows(x0=i, y0=word.mean, x1=i, y1=yplus, angle=90, length=0.1)
            arrows(x0=i, y0=word.mean, x1=i, y1=yminus, angle=90, length=0.1)
          }
        }
        i <- i + 1
      }
    }
    else if(plot.type=="bar") {
      require(ggplot2)
      means.and.ses <- ddply(dat,c("region","cond"),function(df) return(c(rt=mean(df$rt),rt.se=se(df$rt))))
      ##means <- with(dat,aggregate(list(rt=rt),list(region=region,list(cond=cond)),mean,na.rm=T))
      ##ses <- with(dat,tapply(rt,list(region,cond),se,na.rm=T))
      dodge <- position_dodge(width=0.9)
      my.plot <- qplot(region,rt,fill=factor(cond),data=subset(means.and.ses, ! is.na(region)),geom="bar",position="dodge")
      print(my.plot + geom_linerange(aes(ymax=rt+rt.se,ymin=rt-rt.se),position=dodge) + scale_fill_manual(values=col) + opts(title=main))

    }
    else {
      stop(paste("Error:",type,"is not a recognized type of plot for RTs."))
    }
}



# pretty print for Anova results (produces, e.g., 'F1 = 3.24, p < .01; F2...')
print.anova <- function(f1.aov, a.string, f.type,f.sigdigits=2, p.sigdigits=3) {
  ##cat("Printing anova...\n")
  f.sprintf <- paste("%5.", f.sigdigits, "f", sep="")
  p.sprintf <- paste("%5.", p.sigdigits, "f", sep="")
  f1.aov.summary <- summary(f1.aov)[[paste("Error:", a.string)]]
  if (is.null(f1.aov.summary))
  	{ return(NA)}
  else {
	  f1.aov.summary <- data.frame(f1.aov.summary[[1]])
	  df1 <- f1.aov.summary$Df[1]
	  resid.pos <- length(f1.aov.summary$Df)
	  df2 <- f1.aov.summary$Df[resid.pos]
	  f <- f1.aov.summary$"F.value"[1]
	  p <- f1.aov.summary$"Pr..F."[1]
	  f <- round(f, 3)
	  
	  if (f < 1){
	    cat(f.type, "(", df1, ",", df2, ") < 1", sep='')  
	    }
	  else if (p < .001) {
	    cat(f.type, "(", df1, ",", df2, ") = ", sprintf(f.sprintf,f), ", p < .001", sep='')
	  }
	  else {
	    p <- round(p, 3)
	    cat(f.type, "(", df1, ",", df2, ") = ", sprintf(f.sprintf,f), ", p = ", sprintf(p.sprintf,p), sep='')
	  }
	  invisible(f1.aov.summary)
  }
  
}


# first cut outlier removal
first.cut <- function(dat, rt.name='rt', lower=100, upper=5000, factors=c(), verbose=T) {
    rt <- dat[[rt.name]]
    too.low <- (rt < lower)
    too.high <- (rt > upper)
    
    dat$joint.cond <- ''
    if (length(factors) >= 1) {
        for (i in 1:length(factors)) {
            dat$joint.cond <- paste(dat$joint.cond, dat[[factors[i]]])
        }
    }
    dat$joint.cond <- factor(dat$joint.cond)

    if (verbose) {
      cat('RTs too low:\n')
      print(tapply(too.low, list(dat$joint.cond), sum))
      cat('RTs too high:\n')
      print(tapply(too.high, list(dat$joint.cond), sum))
    }
    return(too.low | too.high)
}

# interquartile range (IR) = summary(b)[["3rd Qu."]] - summary(b)[["1st Qu."]]
# remove anything 3rdQu + 1.5IR
find.outliers <- function(dat, factors=c(), region.name='region',
                          region.list=levels(dat[[region.name]]), method='sd', 
                          multiplier=3, rt.name='rt',
						  replace=F, verbose=T) {
  region.list ## for reasons I cannot fathom, this is necessary --
              ## without it, things may not work when region.list isn't
              ## specified!  remove any residual RTs that are more than
              ## [num_sds] sd's away from mean per word and condition
    cond.cols <- subset(dat, select=factors)
    dat <- data.frame(rt=dat[[rt.name]], region=dat[[region.name]],
                      cond.cols)

    dat$joint.cond <- ''
    if (length(factors) >= 1) {
        for (i in 1:length(factors)) {
            dat$joint.cond <- paste(dat$joint.cond, dat[[factors[i]]])
        }
    }
    dat$joint.cond <- factor(dat$joint.cond)
    original.size <- length(subset(dat$rt, dat[[region.name]] %in% region.list))
    to.remove <- rep(F,nrow(dat))
    
    for(reg in region.list) {
        for (con in levels(dat$joint.cond)) {
            con.dat <- subset(dat, dat$region==reg & dat$joint.cond==con)
            con.max <- 0
            con.min <- 0
            if(method == 'IQR' | method == 'iqr'){
				thirdQuartile = summary(con.dat$rt)[["3rd Qu."]] 
				firstQuartile = summary(con.dat$rt)[["1st Qu."]]
                iqRange = thirdQuartile - firstQuartile
				con.max <- thirdQuartile + multiplier*iqRange
                con.min <- firstQuartile - multiplier*iqRange
            }else if(method == 'sd'){
       	        con.max <- mean(con.dat$rt) + multiplier*sd(con.dat$rt)
                con.min <- mean(con.dat$rt) - multiplier*sd(con.dat$rt)
            }else{
                cat('Error in find.outliers(). method is neither sd nor IQR\n')
            }
            con.remove <- ((dat$rt > con.max) | (dat$rt < con.min)) & dat$joint.cond==con & dat$region == reg
            to.remove <- to.remove | con.remove
            dat$rt[con.remove==T] <- con.max
            if (verbose) {
              cat(sprintf("%s\t%s\told mean = %.0f; max = %.0f; min = %.0f; rejected = %d\n",
                          reg, con, mean(con.dat$rt), con.max, con.min, sum(con.remove, na.rm=T)))
            }
        }
    }

  percent.remove <- sum(to.remove, na.rm=T) / original.size * 100

  if (verbose) {
    cat("The percent outliers was", percent.remove, '%', '\n')
  }
	if(replace){
		return(dat$rt)
	}else{
    	return(to.remove)
	}
}

# makes a formula for Anovas, using a dependent variable, a number of conditions
# and a random effect (e.g., participant or item)
build.formula <- function(dependent, conditions, ranef) {
    cond.string <- conditions[1]
    if (length(conditions) > 1) {
       for (i in 2:length(conditions)) {
           cond.string <- paste(cond.string, '*', conditions[i])
       }
    }
    form <- paste(dependent, '~', cond.string, "+ Error(", ranef,
                  "/(", cond.string, "))")
    return(form)
}

print.anova.f1.f2 <- function(indep, f1.aov, f2.aov, ranef.f1, ranef.f2,f.sigdigits=2,p.sigdigits=3) {
  cat(paste(indep, ': ', sep=''))
  f1 <- print.anova(f1.aov, paste(ranef.f1, ':', indep, sep=''), 'F1',f.sigdigits,p.sigdigits)
  cat('; ')
  f2 <- print.anova(f2.aov, paste(ranef.f2, ':', indep, sep=''), 'F2',f.sigdigits=f.sigdigits,p.sigdigits=p.sigdigits)
  cat('\n')
  invisible(list(f1=f1,f2=f2))
}
        
analyze.rts <- function(dat, factors, region.list, subj.name = 'subj',
                        item.name='item', rt.name='rt', region.name='region', do.plot=TRUE,plot.type="line",do.anovas=TRUE,f.sigdigits=2, p.sigdigits=3,...){
  ##cat("###do anovas is ", do.anovas, "\n")
  cond.cols <- subset(dat, select=factors)
  dat <- data.frame(subj=dat[[subj.name]], item=dat[[item.name]],
                    rt=dat[[rt.name]], region=dat[[region.name]], cond.cols)

                                        # make the 'by' list for f1 and f2 aggregation
  by.text.f1 <- make.by.text(c('region', 'subj', factors))
  by.text.f2 <- make.by.text(c('region', 'item', factors))
  by.list.f1 <- eval(parse(text=by.text.f1))
  by.list.f2 <- eval(parse(text=by.text.f2))

                                        # aggregate data for f1 and f2
  dat.f1 <- aggregate(list(rt = dat$rt), by=by.list.f1, mean)
  dat.f2 <- aggregate(list(rt = dat$rt), by=by.list.f2, mean)
  dat.f1$region <- factor(dat.f1$region, levels=region.list, ordered=T)
  dat.f2$region <- factor(dat.f2$region, levels=region.list, ordered=T)
                                        # print means
                                        # - first combine conditions to create a super-condition
  dat.f1$joint.cond <- ''
  dat.f2$joint.cond <- ''
  for (i in 1:length(factors)) {
    dat.f1$joint.cond <- paste(dat.f1$joint.cond,
                               dat.f1[[factors[i]]])
    dat.f2$joint.cond <- paste(dat.f2$joint.cond,
                               dat.f2[[factors[i]]])
  }
  
                                        # print means/SEs by condition by subject
  cat('\nMean RT by condition (by subject):\n')
  subj.means <- tapply(dat.f1$rt, list(cond=dat.f1$joint.cond, 
                                       region=dat.f1$region), rounded.mean)
  print(subj.means)
  cat('\nRT standard error by condition (by subject):\n')
  subj.ses <- tapply(dat.f1$rt, list(cond=dat.f1$joint.cond,
                                     region=dat.f1$region), rounded.se)
  print(subj.ses)

  
                                        # print means/SEs by condition by item
  cat('\nMean RT by condition (by item):\n')
  item.means <- tapply(dat.f2$rt, list(cond=dat.f2$joint.cond,
                                       region=dat.f2$region), rounded.mean)
  print(item.means)
  cat('\nRT standard error by condition (by item):\n')
  item.ses <- tapply(dat.f2$rt, list(cond=dat.f2$joint.cond,
                                     region=dat.f2$region), rounded.se)
  print(item.ses)

  ## graph RTs, with error bars
  dat.f1$joint.cond <- factor(dat.f1$joint.cond)
  if(do.plot)
    plot.rts(dat.f1, plot.type=plot.type,...)
  
  ## do anovas for each region
  if(do.anovas) {
    xx <- list()
    for(reg in region.list){
      xx[[reg]] <- list()
      dat.reg.f1 <- subset(dat.f1, region == reg)
      dat.reg.f2 <- subset(dat.f2, region == reg)
      
      ## make sure there are multiple values of each factor in this level
      reg.factors <- c()
      for(fact in factors) {
        ##cat("###levels"); print(levels(dat.reg.f1[[fact]][drop=T])); print(tapply(dat.reg.f1[[fact]],dat.reg.f1[[fact]], length))
        if (length(levels(dat.reg.f1[[fact]][drop=T])) > 1) {
          reg.factors <- c(reg.factors, fact)
        }
      }
      if(length(reg.factors) == 0) {
        cat(paste('\nNo factors for region ',reg,"; skipping.\n",sep=""))
      }
      else {
        ## create anovas
        f1.formula <- build.formula("rt", reg.factors, "subj")
        f2.formula <- build.formula("rt", reg.factors, "item")
        f1.aov <- aov(as.formula(f1.formula), dat.reg.f1)
        f2.aov <- aov(as.formula(f2.formula), dat.reg.f2)
        
        ## debug info
        ## print(attr(f1.aov,"call"))
        ## print(summary(f1.aov))
        ## print(attr(f2.aov,"call"))
        ## print(summary(f2.aov))
        
        ## create a list of the fully crossed conditions to test
        test.list <- create.factorial(reg.factors)

        ## print results of anova
        cat(sprintf("\nRegion: %s\n", reg))
        ##cat("###Factors existing: "); print(test.list)
        for(i in 1:length(test.list)) {
          xx[[reg]][[test.list[i]]] <- print.anova.f1.f2(test.list[i], f1.aov, f2.aov,
                                                         'subj', 'item',f.sigdigits=f.sigdigits, p.sigdigits=p.sigdigits)
        }
      }
    }
  } else { xx = NA }
  invisible(list(subj.mean=subj.means,subj.se=subj.ses,item.mean=item.means,item.se=item.ses,aov=xx))
}

mean.se.table <- function(means, ses,nchar.mean=3,prec.mean=2,nchar.se=nchar.mean,prec.se=prec.mean) {
  d <- dim(means)
  dn <- attr(means, "dimnames")
  m <- sapply(means,function(x) sprintf(paste("%",nchar.mean,".",prec.mean,"f",sep=""), x))
  s <- sapply(ses,function(x) sprintf(paste("%",nchar.se,".",prec.se,"f",sep=""), x))
  result <- paste(m, " (", s, ")",sep="")
  dim(result) <- d
  attr(result, "dimnames") <- dn
  result
}

format.F.statistic <- function(x,p,dec=2,for.latex=F,signif.labels) {
    result <- ifelse(x<1, "< 1", sprintf(paste("%",2,".",dec,"f",sep=""), x))
    if(p < 0.001)
      result <- paste(result,signif.labels[4],sep="")
    else if(p < 0.01)
      result <- paste(result,signif.labels[3],sep="")
    else if(p < 0.05)
      result <- paste(result,signif.labels[2],sep="")
    else if(p < 0.1)
      result <- paste(result,signif.labels[1],sep="")
  if(for.latex)
    return(paste("$",result,"$",sep=""))
  else
    return(result)
}


stat.extractor <- function(x, row.name,dec=2,for.latex=F,signif.labels) {
  row.number <- grep(paste("^",row.name," *$",sep=""), row.names(x$f1))
  f.f1 <- x$f1[row.number,4]
  p.f1 <- x$f1[row.number,5]
  ##name.f1 <- paste("F1(",x$f1[row.name,1],","x$f1["Residuals",1],")",sep="")
  f.f2 <- x$f2[row.number,4]
  p.f2 <- x$f2[row.number,5]
  ##name.f2 <- paste("F1(",x$f2[row.name,1],","x$f2["Residuals",1],")",sep="")
  return(c(format.F.statistic(f.f1,p.f1,dec=dec,for.latex=for.latex,signif.labels=signif.labels),format.F.statistic(f.f2,p.f2,dec=dec,for.latex=for.latex,signif.labels=signif.labels)))
}

f1.f2.block.helper <- function(x,row.names,dec=2,for.latex=F,signif.labels) {
  temp <- lapply(row.names, function(row.name) stat.extractor(x[[row.name]],row.name,dec=dec,for.latex=for.latex,signif.labels=signif.labels))
  result <- matrix(unlist(temp),ncol=2,byrow=TRUE)
  attr(result,"dimnames")[[2]] <- c("F1","F2")
  return(result)
}

f1.f2.table <- function(aov.list, dec=2, for.latex=F,signif.labels=c(".","*","**","***")) {
  ##row.names <- names(aov.list[[1]])
  tmp <- lapply(aov.list, function(x) {
    row.names <- names(x)
    tmp1 <- f1.f2.block.helper(x, row.names,dec=dec,for.latex=for.latex,signif.labels=signif.labels)
    dimnames(tmp1)[[1]] <- row.names
    return(tmp1)
  })
  ##result <- do.call('cbind',tmp)
  ##row.names(result) <- row.names
  ##return(result)
  return(colmerge(tmp))
}

### Merge rows even when there are different sets of conditions relevant for each case
colmerge <- function(xs) {
  f <- function(y,z) {
    bools <- y == z
    if(sum(bools) == 0)
      return(-1)
    else
      return(which.max(bools))
  }
  result <- xs[[1]]
  if(length(xs) > 1)
    for(i in 2:length(xs)) {
      x <- xs[[i]]
      indices.in.result <- sapply(rownames(x), function(y) f(y, rownames(result)))
      result.indices.in.x <- sapply(rownames(result), function(y) f(y, rownames(x)))
      rows.in.result <- indices.in.result > 0
      rows.not.in.result <- indices.in.result < 0
      result.rows.in.x <- result.indices.in.x > 0
      result.rows.not.in.x <- result.indices.in.x < 0
      result <- rbind(result,matrix(NA,sum(rows.not.in.result),dim(result)[2]))
      x1 <- matrix(NA,dim(result)[1],dim(x)[2]) ## the new columns to add
      dimnames(x1)[[2]] <- dimnames(x)[[2]]
      x1[indices.in.result[rows.in.result],] <- x[rows.in.result,]
      x1[seq(dim(x)[1],length.out=sum(rows.not.in.result),by=-1),] <- x[rows.not.in.result,]
      result <- cbind(result,x1)
    }
  return(result)
}

cpl.legend <- function (x, y = NULL, legend, fill = NULL, col = par("col"), 
    border = "black", lty, lwd, pch, angle = 45, density = NULL, 
    bty = "o", bg = par("bg"), box.lwd = par("lwd"), box.lty = par("lty"), 
    box.col = par("fg"), pt.bg = NA, cex = 1, pt.cex = cex, pt.lwd = lwd, 
    xjust = 0, yjust = 1, x.intersp = 1, y.intersp = 1, adj = c(0, 
        0.5), text.width = NULL, text.col = par("col"), merge = do.lines && 
        has.pch, trace = FALSE, plot = TRUE, ncol = 1, horiz = FALSE, 
    title = NULL, inset = 0, xpd, title.col = text.col, seg.len=2,seg.len.mult=1) 
{
  seg.len <- seg.len * seg.len.mult
    if (missing(legend) && !missing(y) && (is.character(y) || 
        is.expression(y))) {
        legend <- y
        y <- NULL
    }
    mfill <- !missing(fill) || !missing(density)
    if (!missing(xpd)) {
        op <- par("xpd")
        on.exit(par(xpd = op))
        par(xpd = xpd)
    }
    title <- as.graphicsAnnot(title)
    if (length(title) > 1) 
        stop("invalid title")
    legend <- as.graphicsAnnot(legend)
    n.leg <- if (is.call(legend)) 
        1
    else length(legend)
    if (n.leg == 0) 
        stop("'legend' is of length 0")
    auto <- if (is.character(x)) 
        match.arg(x, c("bottomright", "bottom", "bottomleft", 
            "left", "topleft", "top", "topright", "right", "center"))
    else NA
    if (is.na(auto)) {
        xy <- xy.coords(x, y)
        x <- xy$x
        y <- xy$y
        nx <- length(x)
        if (nx < 1 || nx > 2) 
            stop("invalid coordinate lengths")
    }
    else nx <- 0
    xlog <- par("xlog")
    ylog <- par("ylog")
    rect2 <- function(left, top, dx, dy, density = NULL, angle, 
        ...) {
        r <- left + dx
        if (xlog) {
            left <- 10^left
            r <- 10^r
        }
        b <- top - dy
        if (ylog) {
            top <- 10^top
            b <- 10^b
        }
        rect(left, top, r, b, angle = angle, density = density, 
            ...)
    }
    segments2 <- function(x1, y1, dx, dy, ...) {
        x2 <- x1 + dx
        if (xlog) {
            x1 <- 10^x1
            x2 <- 10^x2
        }
        y2 <- y1 + dy
        if (ylog) {
            y1 <- 10^y1
            y2 <- 10^y2
        }
        segments(x1, y1, x2, y2, ...)
    }
    points2 <- function(x, y, ...) {
        if (xlog) 
            x <- 10^x
        if (ylog) 
            y <- 10^y
        points(x, y, ...)
    }
    text2 <- function(x, y, ...) {
        if (xlog) 
            x <- 10^x
        if (ylog) 
            y <- 10^y
        text(x, y, ...)
    }
    if (trace) 
        catn <- function(...) do.call("cat", c(lapply(list(...), 
            formatC), list("\n")))
    cin <- par("cin")
    Cex <- cex * par("cex")
    if (is.null(text.width)) 
        text.width <- max(abs(strwidth(legend, units = "user", 
            cex = cex)))
    else if (!is.numeric(text.width) || text.width < 0) 
        stop("'text.width' must be numeric, >= 0")
    xc <- Cex * xinch(cin[1L], warn.log = FALSE)
    yc <- Cex * yinch(cin[2L], warn.log = FALSE)
    if (xc < 0) 
        text.width <- -text.width
    xchar <- xc
    xextra <- 0
    yextra <- yc * (y.intersp - 1)
    ymax <- yc * max(1, strheight(legend, units = "user", cex = cex)/yc)
    ychar <- yextra + ymax
    if (trace) 
        catn("  xchar=", xchar, "; (yextra,ychar)=", c(yextra, 
            ychar))
    if (mfill) {
        xbox <- xc * 0.8
        ybox <- yc * 0.5
        dx.fill <- xbox
    }
    do.lines <- (!missing(lty) && (is.character(lty) || any(lty > 
        0))) || !missing(lwd)
    n.legpercol <- if (horiz) {
        if (ncol != 1) 
            warning("horizontal specification overrides: Number of columns := ", 
                n.leg)
        ncol <- n.leg
        1
    }
    else ceiling(n.leg/ncol)
    has.pch <- !missing(pch) && length(pch) > 0
    if (do.lines) {
        x.off <- if (merge) 
            -0.7
        else 0
    }
    else if (merge) 
        warning("'merge = TRUE' has no effect when no line segments are drawn")
    if (has.pch) {
        if (is.character(pch) && !is.na(pch[1L]) && nchar(pch[1L], 
            type = "c") > 1) {
            if (length(pch) > 1) 
                warning("not using pch[2..] since pch[1L] has multiple chars")
            np <- nchar(pch[1L], type = "c")
            pch <- substr(rep.int(pch[1L], np), 1L:np, 1L:np)
        }
    }
    if (is.na(auto)) {
        if (xlog) 
            x <- log10(x)
        if (ylog) 
            y <- log10(y)
    }
    if (nx == 2) {
        x <- sort(x)
        y <- sort(y)
        left <- x[1L]
        top <- y[2L]
        w <- diff(x)
        h <- diff(y)
        w0 <- w/ncol
        x <- mean(x)
        y <- mean(y)
        if (missing(xjust)) 
            xjust <- 0.5
        if (missing(yjust)) 
            yjust <- 0.5
    }
    else {
        h <- (n.legpercol + (!is.null(title))) * ychar + yc
        w0 <- text.width + (x.intersp + 1) * xchar
        if (mfill) 
            w0 <- w0 + dx.fill
        if (do.lines) 
            w0 <- w0 + (seg.len + x.off) * xchar
        w <- ncol * w0 + 0.5 * xchar
        if (!is.null(title) && (abs(tw <- strwidth(title, units = "user", 
            cex = cex) + 0.5 * xchar)) > abs(w)) {
            xextra <- (tw - w)/2
            w <- tw
        }
        if (is.na(auto)) {
            left <- x - xjust * w
            top <- y + (1 - yjust) * h
        }
        else {
            usr <- par("usr")
            inset <- rep(inset, length.out = 2)
            insetx <- inset[1L] * (usr[2L] - usr[1L])
            left <- switch(auto, bottomright = , topright = , 
                right = usr[2L] - w - insetx, bottomleft = , 
                left = , topleft = usr[1L] + insetx, bottom = , 
                top = , center = (usr[1L] + usr[2L] - w)/2)
            insety <- inset[2L] * (usr[4L] - usr[3L])
            top <- switch(auto, bottomright = , bottom = , bottomleft = usr[3L] + 
                h + insety, topleft = , top = , topright = usr[4L] - 
                insety, left = , right = , center = (usr[3L] + 
                usr[4L] + h)/2)
        }
    }
    if (plot && bty != "n") {
        if (trace) 
            catn("  rect2(", left, ",", top, ", w=", w, ", h=", 
                h, ", ...)", sep = "")
        rect2(left, top, dx = w, dy = h, col = bg, density = NULL, 
            lwd = box.lwd, lty = box.lty, border = box.col)
    }
    xt <- left + xchar + xextra + (w0 * rep.int(0:(ncol - 1), 
        rep.int(n.legpercol, ncol)))[1L:n.leg]
    yt <- top - 0.5 * yextra - ymax - (rep.int(1L:n.legpercol, 
        ncol)[1L:n.leg] - 1 + (!is.null(title))) * ychar
    if (mfill) {
        if (plot) {
            fill <- rep(fill, length.out = n.leg)
            rect2(left = xt, top = yt + ybox/2, dx = xbox, dy = ybox, 
                col = fill, density = density, angle = angle, 
                border = border)
        }
        xt <- xt + dx.fill
    }
    if (plot && (has.pch || do.lines)) 
        col <- rep(col, length.out = n.leg)
    if (missing(lwd)) 
        lwd <- par("lwd")
    if (do.lines) {
        if (missing(lty)) 
            lty <- 1
        lty <- rep(lty, length.out = n.leg)
        lwd <- rep(lwd, length.out = n.leg)
        ok.l <- !is.na(lty) & (is.character(lty) | lty > 0)
        if (trace) 
            catn("  segments2(", xt[ok.l] + x.off * xchar, ",", 
                yt[ok.l], ", dx=", seg.len * xchar, ", dy=0, ...)")
        if (plot) 
            segments2(xt[ok.l] + x.off * xchar, yt[ok.l], dx = seg.len * 
                xchar, dy = 0, lty = lty[ok.l], lwd = lwd[ok.l], 
                col = col[ok.l])
        xt <- xt + (seg.len + x.off) * xchar
    }
    if (has.pch) {
        pch <- rep(pch, length.out = n.leg)
        pt.bg <- rep(pt.bg, length.out = n.leg)
        pt.cex <- rep(pt.cex, length.out = n.leg)
        pt.lwd <- rep(pt.lwd, length.out = n.leg)
        ok <- !is.na(pch) & (is.character(pch) | pch >= 0)
        x1 <- (if (merge && do.lines) 
            xt - (seg.len/2) * xchar
        else xt)[ok]
        y1 <- yt[ok]
        if (trace) 
            catn("  points2(", x1, ",", y1, ", pch=", pch[ok], 
                ", ...)")
        if (plot) 
            points2(x1, y1, pch = pch[ok], col = col[ok], cex = pt.cex[ok], 
                bg = pt.bg[ok], lwd = pt.lwd[ok])
    }
    xt <- xt + x.intersp * xchar
    if (plot) {
        if (!is.null(title)) 
            text2(left + w/2, top - ymax, labels = title, adj = c(0.5, 
                0), cex = cex, col = title.col)
        text2(xt, yt, labels = legend, adj = adj, cex = cex, 
            col = text.col)
    }
    invisible(list(rect = list(w = w, h = h, left = left, top = top), 
        text = list(x = xt, y = yt)))
}
