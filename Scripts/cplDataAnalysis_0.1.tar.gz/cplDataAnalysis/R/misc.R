#standard error
se <- function(x,na.rm=F) {
  #sqrt(var(x,na.rm=T)/length(subset(x,! is.na(x))))
  #print(sum(is.na(x)))
  if(na.rm) x <- subset(x,! is.na(x))
  sqrt(var(x)/length(x))
}


# works for up to two-way tables.
print.mean.se <- function(measure,factors,na.rm=T) {
  x1.mean <- tapply(measure,factors,mean,na.rm=na.rm)
  #print(x1.mean)
  x1.se <- tapply(measure,factors,se,na.rm=na.rm)
  x1 <- c(t(x1.mean),t(x1.se))
  dim(x1) <- c(length(x1)/2,2)
  #print(x1)
  #print(interleave.names(t(x1.mean)))
  #dimnames(x1)[[1]] <- interleave.names(x1.mean)
  #dimnames(x1)[[2]] <- c("Mean","SE")
  dimnames(x1) <- list(interleave.names(x1.mean),c("Mean","SE"))
  print(x1)
}

interleave.names <-  function(matrix) {
  if(length(dimnames(matrix))==1) {
    dimnames(matrix)[[1]]
  }
  else { # 2d matrix
    matrix <- t(matrix)
    result <- c()
    #print(dimnames(matrix))
    for(i in 1:length(dimnames(matrix)[[2]])) {
      result <- c(result,append.names(dimnames(matrix)[[2]][i],dimnames(matrix)[[1]]))
    }
    result
  }
}

append.names <- function(name,names) {
  sapply(names,function(x) paste(name,x,sep=""))
}

means <- function(data,measure="Crit",fn=mean,f.cond=list("Cond"),ignorezero=FALSE,sxi=TRUE) {
  measure1 = data[[measure]]
  if(ignorezero) {
    data <- subset(data, measure1 > 0)
    measure1 <- subset(measure1, measure1 > 0)
  }
  get.factors <- function(factor.name) list(factor(data[[factor.name]]))
  f <- sapply(f.cond,get.factors)
  if(sxi)
    f <- c(f,list(factor(data$Subj)))
  else # ixs
    f <- c(f,list(factor(data$Item)))
  apply(tapply(measure1,f,mean,na.rm=T),1:(length(f)-1),fn,na.rm=T)
}

meanse <- function(data,measure="Crit",f.cond=list("Cond"),column.names=NULL,ignorezero=FALSE,sxi=TRUE,round.digits=-1) {
  result <- c(means(data,measure,mean,f.cond,ignorezero,sxi),
              means(data,measure,se,f.cond,ignorezero,sxi))
  dim(result) <- c(length(result)/2,2)
  result <- t(result)
  rownames(result) <- c("mean","se")
  colnames(result) <- column.names
  if(round.digits>=0) result <- round(result,round.digits)
  result
}

barplot.with.errbars <- function (means, ses, max.cutoff=NULL,min.cutoff=NULL,baseline = 0, names.arg=NULL,ylim=NULL,col = "grey", width=0.8,space=0.25,density=75,las=3,cex.names=par("cex.axis"),...) 
{
  f <- function(x) {
    if(! is.null(max.cutoff) & x > max.cutoff) {
      return(max.cutoff)
    } else if(! is.null(min.cutoff) & x < min.cutoff) {
      return(min.cutoff)
    } else {
      return(x)
    }
  }
  my.ylim <- ylim
  if(is.null(my.ylim)) 
    my.ylim <- c(ifelse(min(means) < 0, min(means - ses) * 1.1, 
                        0), ifelse(max(means) > 0, max(means + ses) * 1.1, 0))
  print(my.ylim)
  barplot(c(means), width = 0.8, space = 0.25, names.arg=names.arg, las = las, density = density, 
          col = col, ylim = my.ylim, cex.names=cex.names,...)
  xs <- -0.4 + (1:length(means))
  arrows(xs, sapply(means - ses,f), xs, sapply(means + ses,f), angle = 90, code = 3, 
         length = 0.05, ...)
}

plot.confusion.matrix <- function(m,x=NULL,y=NULL,value=NULL) {
  if(is.matrix(m)) {
    require(reshape)
    require(ggplot2)
    max.val <- max(m)
    dat <- melt(m, varnames=c("X","Y"))
    qplot(factor(X),factor(Y),data=dat,pch=15,cex=dat$value/max.val)
  }
  else { ## is.data.frame(m)
    max.val <- max(m[[value]])
    tmp <- sort(unique(m[[value]]))
    qplot(m[[x]],m[[y]],pch=15,size=factor(m[[value]],levels=tmp)) + scale_size_manual(values=20*tmp/max.val)
    ##plot(m[[x]],m[[y]],pch=15,cex=m[[value]]/max.val)
  }
}
